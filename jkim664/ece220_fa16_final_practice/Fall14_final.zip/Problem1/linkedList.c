#include "linkedList.h"


int DetectLoop(node *head)
{
  //Write code here.
    
}

node *CopyList(node *head)
{
   //Insert Code here. You can change the return statement given.
   
   
   
   return NULL;
}
